# __init__.py
from .oricd import test_function, Orcid